TO SETUP THE ENVIRONMENT FOR DEVELOPING OWLDIFF NEON PLUGIN

1) Setup the Neon 1.2. environment
2) import this plugin using 'Import -> Plugins and Fragments' dialog
3) import the swing2swt plugin that is located in the 'plugins-eclipse' dir in the very same manner
4) for some reason Eclipse seems not to refresh correctly the runtime path sometimes.Thus, it is recommended to clear and readd all classpath entries in the 'runtime' tab of the plugin.xml editor.

TO BUILD THE PLUGIN
5) import the Feature project contained at 'feature-project' dir. This feature can be easily included into your update site.